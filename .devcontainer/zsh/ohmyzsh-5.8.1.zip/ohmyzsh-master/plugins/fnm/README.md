# fnm plugin

This plugin adds autocompletion for [fnm](https://github.com/Schniz/fnm) - a Node.js version manager.

To use it, add `fnm` to the plugins array in your zshrc file:

```zsh
plugins=(... fnm)
```
