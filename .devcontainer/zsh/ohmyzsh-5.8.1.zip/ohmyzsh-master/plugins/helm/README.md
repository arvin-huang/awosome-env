# Helm plugin

This plugin adds completion for [Helm](https://helm.sh/), the Kubernetes package manager.

To use it, add `helm` to the plugins array in your zshrc file:

```zsh
plugins=(... helm)
```
